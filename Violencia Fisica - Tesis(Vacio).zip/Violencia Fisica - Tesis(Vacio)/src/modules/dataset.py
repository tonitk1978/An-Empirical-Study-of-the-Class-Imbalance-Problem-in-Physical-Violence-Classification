import cv2
import os
import random
import numpy as np
from sklearn.model_selection import train_test_split

class DataPreparation:

    violenceVideoPath=None
    noViolenceVideoPath=None
    testViolenceVideoPath=None
    testNoViolenceVideoPath=None
    violenceFramesPath=None
    noViolenceFramesPath=None
    testViolenceFramesPath=None
    testNoViolenceFramesPath=None

    carpeta_imagenes = None
    carpeta_train = None
    carpeta_test = None


    def __init__(self):

        self.violenceVideoPath="../sources/videos/violencia/"
        self.noViolenceVideoPath="../sources/videos/no_violencia/"

        self.testViolenceVideoPath="../sources/test_videos/violencia/"
        self.testNoViolenceVideoPath="../sources/test_videos/no_violencia/"


        self.violenceFramesPath="../sources/frames/violencia/"
        self.noViolenceFramesPath="../sources/frames/no_violencia/"

        self.testViolenceFramesPath="../sources/test_frames/violencia/"
        self.testNoViolenceFramesPath="../sources/test_frames/no_violencia/"

       

    def crearDatasetTrain(self,carpeta_imagenes, carpeta_train, tamaño_imagen=(224, 224)):
        imagenes = []
        etiquetas = []

        # Crear subcarpetas "train" y "test"
        carpeta_train_completa = os.path.join(carpeta_train, "train")
        print(carpeta_train_completa)
        os.makedirs(carpeta_train_completa, exist_ok=True)

        for subcarpeta in ["violencia", "no_violencia"]:
            ruta_subcarpeta = os.path.join(carpeta_imagenes, subcarpeta)
            for nombre_archivo in os.listdir(ruta_subcarpeta):
                if nombre_archivo.endswith((".jpg", ".jpeg", ".png")):
                    ruta_imagen = os.path.join(ruta_subcarpeta, nombre_archivo)
                    imagen = cv2.imread(ruta_imagen)  # Cargar imagen a color
                    imagen_redimensionada = cv2.resize(imagen, tamaño_imagen)
                    imagenes.append(imagen_redimensionada)
                    etiquetas.append(subcarpeta)  # Usar el nombre de la subcarpeta como etiqueta
        X_train=imagenes
        y_train=etiquetas
        # Guardar imágenes redimensionadas en las subcarpetas correspondientes
        for imagen, etiqueta in zip(X_train, y_train):
            carpeta_guardar = os.path.join(carpeta_train_completa, etiqueta)  # Guardar en subcarpeta según etiqueta de texto
            os.makedirs(carpeta_guardar, exist_ok=True)
            cv2.imwrite(os.path.join(carpeta_guardar, etiqueta + '_' + str(np.random.randint(1000000)) + ".jpg"), imagen)            


    def crearDatasetTest(self,carpeta_imagenes_test, carpeta_test, tamaño_imagen=(224, 224)):
   

        imagenes = []
        etiquetas = []

        # Crear subcarpetas "train" y "test"
        #carpeta_train_completa = os.path.join(carpeta_train, "train")
        carpeta_test_completa = os.path.join(carpeta_test, "test")
        #os.makedirs(carpeta_train_completa, exist_ok=True)
        os.makedirs(carpeta_test_completa, exist_ok=True)

        for subcarpeta in ["violencia", "no_violencia"]:
            ruta_subcarpeta = os.path.join(carpeta_imagenes_test, subcarpeta)
            for nombre_archivo in os.listdir(ruta_subcarpeta):
                if nombre_archivo.endswith((".jpg", ".jpeg", ".png")):
                    ruta_imagen = os.path.join(ruta_subcarpeta, nombre_archivo)
                    imagen = cv2.imread(ruta_imagen)  # Cargar imagen a color
                    imagen_redimensionada = cv2.resize(imagen, tamaño_imagen)
                    imagenes.append(imagen_redimensionada)
                    etiquetas.append(subcarpeta)  # Usar el nombre de la subcarpeta como etiqueta

        # Dividir en entrenamiento y prueba
        #X_test, X_test, y_test, y_test = train_test_split(imagenes, etiquetas, test_size=0.3, random_state=42)
        X_test  =imagenes
        y_test=etiquetas
        for imagen, etiqueta in zip(X_test, y_test):
            carpeta_guardar = os.path.join(carpeta_test_completa, etiqueta)  # Guardar en subcarpeta según etiqueta de texto
            os.makedirs(carpeta_guardar, exist_ok=True)
            cv2.imwrite(os.path.join(carpeta_guardar, etiqueta + '_' + str(np.random.randint(1000000)) + ".jpg"), imagen)
    



    def listVideosOfViolence(self):
        # Obtiene el nombre de la carpeta
        ## cambiar segun el tipo de video
        folderName = self.violenceVideoPath
        #folderName = "../../../resources/video/no_violencia/"
        filesList=[]

        # Enlista todos los archivos en la carpeta
        files = os.listdir(folderName)

        # Imprime los nombres de los archivos
        for file in files:
            filesList.append(folderName+file)
            #print(file)
        print(">>>>>>  Tamano de lista: "+str(len(filesList)))
        return filesList 
    
    def listVideosOfViolenceTest(self):
        # Obtiene el nombre de la carpeta
        ## cambiar segun el tipo de video
        folderName = self.testViolenceVideoPath
        #folderName = "../../../resources/video/no_violencia/"
        filesList=[]

        # Enlista todos los archivos en la carpeta
        files = os.listdir(folderName)

        # Imprime los nombres de los archivos
        for file in files:
            filesList.append(folderName+file)
            #print(file)
        print(">>>>>>  Tamano de lista: "+str(len(filesList)))
        return filesList 
    
    def listVideosOfNonViolence(self):
        # Obtiene el nombre de la carpeta
        ## cambiar segun el tipo de video
        folderName = self.noViolenceVideoPath
        #folderName = "../../../resources/video/no_violencia/"
        filesList=[]

        # Enlista todos los archivos en la carpeta
        files = os.listdir(folderName)

        # Imprime los nombres de los archivos
        for file in files:
            filesList.append(folderName+file)
            #print(file)
        print(">>>>>>  Tamano de lista: "+str(len(filesList)))
        return filesList 
    
    def listVideosOfNonViolenceTest(self):
        # Obtiene el nombre de la carpeta
        ## cambiar segun el tipo de video
        folderName = self.testNoViolenceVideoPath
        #folderName = "../../../resources/video/no_violencia/"
        filesList=[]

        # Enlista todos los archivos en la carpeta
        files = os.listdir(folderName)

        # Imprime los nombres de los archivos
        for file in files:
            filesList.append(folderName+file)
            #print(file)
        print(">>>>>>  Tamano de lista: "+str(len(filesList)))
        return filesList 
    

 #   def 

#               

    def writeFrames(self,videoPath,pathFrames):
    
        if not os.path.exists(videoPath):
            print("El archivo de video no existe en la ruta especificada:", videoPath)
        else:
            print("Archivo encontrado:", videoPath)
    
        # Abre el video
        cap = cv2.VideoCapture(videoPath)

        # Establece el número de fotograma en el que comenzar la extracción
        cap.set(cv2.CAP_PROP_POS_FRAMES, 0)

        # Itera sobre todos los fotogramas del video
        while cap.isOpened():
            # Captura el siguiente fotograma
            ret, frame = cap.read()

            # Si el fotograma es válido, lo guarda
            if ret:
                # Redimensiona el fotograma a 100x100 píxeles
                frame = cv2.resize(frame, dsize=(224, 224))

                # Obtiene el nombre del fotograma
                frame_number = cap.get(cv2.CAP_PROP_POS_FRAMES)
                frame_filename = f""+pathFrames + self.nombreAleatorio()
                print(">> Escribiendo frame: "+frame_filename)
                # Guarda el fotograma
                cv2.imwrite(frame_filename, frame)
            else:
                print("Frame invalido")
                break
        print("> Fin de video")
        # Cierra el video
        cap.release()              


    def nombreAleatorio(self):
        # Obtiene una lista de todas las letras y números
        chars = "ABCDEFGHIJKLMNOPRSTUVWXYabcdefghijklmnopqrstuvwxyz0123456789"
        # Genera una secuencia de 10 letras y números aleatorios irrepetibles
        sample=  "".join(random.sample(chars, 30))
        return sample+".jpg"
 



    